from django.test import TestCase

class PrimerTest(TestCase):
    def test_1(self,):
        self.assertEqual(1, 1)